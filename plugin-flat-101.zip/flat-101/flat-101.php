<?php
/**
 * Plugin Name: Flat 101
 * Description: Plugin para Flat 101.
 * Version: 1.0
 * Requires at least: 6.2
 * Requires PHP: 8.2
 * Author: Varuiza
 * Author URI: https://www.linkedin.com/in/varuiza/
 * License: GPL v2 or later
 * License URI: https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain: flat-101
 *
 * Flat 101 is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * any later version.
 *
 * Flat 101 is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the
 * license URI for more details.
 */

defined( 'ABSPATH' ) || die();


// PARTE 1: Desarrollar un plugin básico de WordPress.


// PARTE 1.1: Añadir al final del título de todas las páginas " - Flat101".
/**
 * Función que añade el sufijo " - Flat101" a los títulos de las páginas.
 *
 * @param string $title Título de la página.
 * @param int    $id ID de la página.
 */
function vr_flat_101_title_filter( $title, $id = null ) {
	if ( ! is_admin() && ! is_null( $id ) ) {
		$post = get_post( $id );
		if ( $post instanceof WP_Post && 'page' === $post->post_type ) {
			$title = "{$title} - Flat101";
		}
	}
	return $title;
}
/**
 *  Función que añade al flujo de carga de WordPress la función vr_flat_101_title_filter después de haber cargado los menús para que no modifiquen los títulos de las páginas en caso de que haya alguna página en el menú con el mismo nombre que el título de la página a la que enlaza.
 *
 * @param string $items Elementos del menú.
 */
function vr_add_flat_101_title_filter_after_menu( $items ) {
	add_filter( 'the_title', 'vr_flat_101_title_filter', 10, 2 );
	return $items;
}
add_filter( 'wp_nav_menu_items', 'vr_add_flat_101_title_filter_after_menu', 10, 2 );


// PARTE 1.2: Añadir el meta "og:image" en el <head> en las páginas de posts con el enlace a la imagen destacada.
/**
 * Función que comprueba si un post tiene asignada una imagen destacada y, si la tiene, le añade la URL en la meta etiqueta "og:image".
 */
function vr_flat_101_og_image() {
	global $post;
	if ( is_single() && has_post_thumbnail( $post->ID ) ) {
		echo '<meta property="og:image" content="' . esc_attr( get_the_post_thumbnail_url( $post->ID ) ) . '"/>';
	}
}
add_action( 'wp_head', 'vr_flat_101_og_image', 5 );



/*  PARTE 2: Generar un CPT "Tienda" y consumirlo mediante la API de WordPress  */


// PARTE 2.1: Generar un Custom Post Type "Tienda" con los Custom Fields: Nombre, Dirección y Descripción.
require_once 'inc/cpt-tienda.php';
require_once 'inc/cf-tienda.php';

/**
 * Función que actualiza los permalinks al activar el plugin.
 */
function vr_update_permalinks() {
	flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'vr_update_permalinks' );


// PARTE 2.2: Crear un archivo JS que hace una llamada AJAX a la API de WordPress y obtiene los datos de esas tiendas en formato JSON.
// Resuelto en el archivo /js/shop-list.js del child theme Flat 101.

// PARTE 2.3: Crear un tema básico en WordPress e incluir dicho JavaScript en un template que se llame "Template Name: ShopList".
// Resuelto en el archivo /templates/shop-list.php del child theme Flat 101.
