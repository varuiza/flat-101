<?php

if ( class_exists( 'CF_Shop' ) ) {
	new CF_Shop();
}

class CF_Shop {

	private $post_type         = 'shop';
	private $meta_box_location = 'advanced';
	private $meta_box_title    = 'Información adicional de la tienda';
	private $fields            = array(
		'name'        => array(
			'type'        => 'text',
			'id'          => 'shop_name',
			'label'       => 'Nombre',
			'placeholder' => 'Nombre de la tienda',
		),
		'address'     => array(
			'type'        => 'text',
			'id'          => 'shop_address',
			'label'       => 'Dirección',
			'placeholder' => 'Nombre de la tienda',
		),
		'description' => array(
			'type'        => 'text',
			'id'          => 'shop_description',
			'label'       => 'Descripción',
			'placeholder' => 'Nombre de la tienda',
		),
	);

	public function __construct() {
		add_action( 'add_meta_boxes', array( $this, 'add_meta_boxes' ) );
		add_action( 'save_post', array( $this, 'save_post' ) );
	}

	public function add_meta_boxes() {
		add_meta_box(
			'additional_shop_information',
			$this->meta_box_title,
			array( $this, 'add_meta_box_callback' ),
			$this->post_type,
			$this->meta_box_location
		);
	}

	public function save_post( $post_id ) {
		foreach ( $this->fields as $field ) {
			switch ( $field['type'] ) {
				default:
					if ( isset( $_POST[ $field['id'] ] ) ) {
						$sanitized = sanitize_text_field( $_POST[ $field['id'] ] );
						update_post_meta( $post_id, $field['id'], $sanitized );
					}
			}
		}
	}

	public function add_meta_box_callback() {
		$this->fields_table();
	}

	private function fields_table() {
		?><table class="form-table" role="presentation">
			<tbody style="display:inline-flex;">
		<?php
		foreach ( $this->fields as $field ) {
			?>
					<tr>
						<th style="float:left;" scope="row"><?php $this->label( $field ); ?></th>
						<td style="padding-left:0;"><?php $this->field( $field ); ?></td>
					</tr>
				<?php
		}
		?>
			</tbody>
		</table>
		<?php
	}

	private function label( $field ) {
		switch ( $field['type'] ) {
			default:
				printf(
					'<label class="" for="%s">%s</label>',
					$field['id'],
					$field['label']
				);
		}
	}

	private function field( $field ) {
		switch ( $field['type'] ) {
			default:
				$this->input( $field );
		}
	}

	private function input( $field ) {
		printf(
			'<input style="width:20em;" class="%s" id="%s" name="%s" %s type="%s" value="%s">',
			isset( $field['class'] ) ? $field['class'] : '',
			$field['id'],
			$field['id'],
			isset( $field['pattern'] ) ? "pattern='{$field['pattern']}'" : '',
			$field['type'],
			$this->value( $field )
		);
	}

	private function value( $field ) {
		global $post;
		if ( metadata_exists( 'post', $post->ID, $field['id'] ) ) {
			$value = get_post_meta( $post->ID, $field['id'], true );
		} elseif ( isset( $field['default'] ) ) {
			$value = $field['default'];
		} else {
			return '';
		}
		return str_replace( '\u0027', "'", $value );
	}
}



function add_shop_fields() {
	register_rest_field(
		'shop',
		'shop_name', // Field Name in JSON RESPONSE
		array(
			'get_callback' => function() {
				return get_post_meta( get_the_ID(), 'shop_name', true );
			},
		)
	);
	register_rest_field(
		'shop',
		'shop_address', // Field Name in JSON RESPONSE
		array(
			'get_callback' => function() {
				return get_post_meta( get_the_ID(), 'shop_address', true );
			},
		)
	);
	register_rest_field(
		'shop',
		'shop_description', // Field Name in JSON RESPONSE
		array(
			'get_callback' => function() {
				return get_post_meta( get_the_ID(), 'shop_description', true );
			},
		)
	);
}
	add_action( 'rest_api_init', 'add_shop_fields' );
