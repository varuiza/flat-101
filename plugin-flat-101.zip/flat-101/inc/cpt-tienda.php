<?php
/**
 * CPT Tiendas.
 */

if ( ! function_exists( 'vr_cpt_shop' ) ) {

	/**
	 * Función que crea el CPT Shop, que tiene el archivo en /tiendas.
	 */
	function vr_cpt_shop() {

		$labels  = array(
			'name'                  => _x( 'Tiendas', 'Post Type General Name', 'flat-101' ),
			'singular_name'         => _x( 'Tienda', 'Post Type Singular Name', 'flat-101' ),
			'menu_name'             => __( 'Tiendas', 'flat-101' ),
			'name_admin_bar'        => __( 'Post Type', 'flat-101' ),
			'archives'              => __( 'Item Archives', 'flat-101' ),
			'attributes'            => __( 'Item Attributes', 'flat-101' ),
			'parent_item_colon'     => __( 'Parent Item:', 'flat-101' ),
			'all_items'             => __( 'Todas las tiendas', 'flat-101' ),
			'add_new_item'          => __( 'Add New Item', 'flat-101' ),
			'add_new'               => __( 'Añadir nueva', 'flat-101' ),
			'new_item'              => __( 'New Item', 'flat-101' ),
			'edit_item'             => __( 'Edit Item', 'flat-101' ),
			'update_item'           => __( 'Update Item', 'flat-101' ),
			'view_item'             => __( 'View Item', 'flat-101' ),
			'view_items'            => __( 'View Items', 'flat-101' ),
			'search_items'          => __( 'Search Item', 'flat-101' ),
			'not_found'             => __( 'Not found', 'flat-101' ),
			'not_found_in_trash'    => __( 'Not found in Trash', 'flat-101' ),
			'featured_image'        => __( 'Featured Image', 'flat-101' ),
			'set_featured_image'    => __( 'Set featured image', 'flat-101' ),
			'remove_featured_image' => __( 'Remove featured image', 'flat-101' ),
			'use_featured_image'    => __( 'Use as featured image', 'flat-101' ),
			'insert_into_item'      => __( 'Insert into item', 'flat-101' ),
			'uploaded_to_this_item' => __( 'Uploaded to this item', 'flat-101' ),
			'items_list'            => __( 'Items list', 'flat-101' ),
			'items_list_navigation' => __( 'Items list navigation', 'flat-101' ),
			'filter_items_list'     => __( 'Filter items list', 'flat-101' ),
		);
		$rewrite = array(
			'slug'       => 'tiendas',
			'with_front' => true,
			'pages'      => true,
			'feeds'      => true,
		);
		$args    = array(
			'label'               => __( 'Tienda', 'flat-101' ),
			'description'         => __( 'CPT Tienda', 'flat-101' ),
			'labels'              => $labels,
			'supports'            => array( 'title', 'editor', 'thumbnail', 'custom-fields' ),
			'hierarchical'        => false,
			'public'              => true,
			'show_ui'             => true,
			'show_in_menu'        => true,
			'menu_position'       => 5,
			'menu_icon'           => 'dashicons-cart',
			'show_in_admin_bar'   => true,
			'show_in_nav_menus'   => true,
			'can_export'          => true,
			'has_archive'         => true,
			'exclude_from_search' => false,
			'publicly_queryable'  => true,
			'rewrite'             => $rewrite,
			'capability_type'     => 'post',
			'show_in_rest'        => true,
			'rest_base'           => 'shops',
		);
		register_post_type( 'shop', $args );
	}
	add_action( 'init', 'vr_cpt_shop', 0 );

}
