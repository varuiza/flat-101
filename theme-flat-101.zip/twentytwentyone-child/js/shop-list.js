jQuery(document).ready(function($) {
    $.ajax({
        url: '/wp-json/wp/v2/shops?_embed'
    }).done(function(data) {
        data.forEach(shop => {
            $('#shops-cards').append(displayShop(
                shopURL     = shop.link,
                title       = shop.title.rendered,
                imageURL    = shop._embedded['wp:featuredmedia'][0].source_url,
                name        = shop.shop_name,
                address     = shop.shop_address,
                description = shop.shop_description
                ));
        });
    }
    );
});

function displayShop( shopURL, title, imageURL, name, address, description ) {
    let shopCardBody =`
        <div class="shop-card">
            <h3 class="shop-card__title"><a href="`+ shopURL +`">` + title + `</a></h3>
            <a href="`+ shopURL +`"><img class="shop-card__image" src="`+ imageURL +`"/></a>
            <p>Nombre: `+ name +`</p>
            <p>Dirección: `+ address +`</p>
            <p>Descripción: `+ description +`</p>
        </div>
    `;
    console.log(shopCardBody);
    return shopCardBody;
}