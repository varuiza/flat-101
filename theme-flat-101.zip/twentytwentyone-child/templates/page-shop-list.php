<?php
/** Template Name: ShopList */

// Añadimos a la cola de WordPress los recursos que necesitaremos en este template.
wp_enqueue_script( 'jquery' );
wp_enqueue_script( 'shop-list-logic', get_stylesheet_directory_uri() . '/js/shop-list.js', array( 'jquery' ), null, true );
wp_enqueue_style( 'shop-list-styles', get_stylesheet_directory_uri() . '/css/shop-list.css' );

get_header();

/* Start the Loop */
while ( have_posts() ) :
	the_post();
	get_template_part( 'template-parts/content/content-page' );
	?><div id="shops-cards"></div>
	<?php
endwhile; // End of the loop.

get_footer();
